[DS3] Use DualShock 3 Controller with POPStarter
______________________________________________________________________________________________________________

Credits : belek666 for the DualShock 3 modules.

Notes : 
. works only with WIP 06 beta 17, does NOT work with the prototypes (due to an issue affecting the IRX loader). 
. compiled and provided by belek666 on 2017/06/25 @ASSEMblergames.

These modules are ready to use � you just need to copy them into your POPS folder as they are.

POPS/MODULE_1.IRX
POPS/MODULE_2.IRX

FYI : 
. MODULE_1.IRX = USBD.IRX 
. MODULE_2.IRX = bt_pademu.irx

You can switch from analog to digital mode by pressing PS + SELECT � with $D2LS written in a GAME/CHEATS.TXT file.

~shaolinassassin, 2017/10/17