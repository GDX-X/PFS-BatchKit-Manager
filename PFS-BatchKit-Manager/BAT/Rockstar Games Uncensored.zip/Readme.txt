These cheat codes will reactivate blood and rampage and dismemberment

How do I know my version of my Grand Theft Auto.

Mount or Open your .ISO with Winrar and Open system.cnf and check VER =

.CHT for Open PS2 Loader
.PNACH for PCSX2

Why the Vice City German version doesn't have the blood. 
Because I think rockstar has removed the blood texture for the German version
(If you find a solution open a issue)


Discord: GDX#5466