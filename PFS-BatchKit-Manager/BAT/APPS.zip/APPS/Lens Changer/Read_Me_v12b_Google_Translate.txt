PS2 LENSCHANGER version 1.2 (beta)  *****Note: This document was translated from NUEVA VERSI�N v12b.txt using Google Translate*****
------------------------------------------------------------------------
 (c) 2004-2006, Dampro  (dampro@gmail.com)
    http://www.spainconsoles.com
    http://www.murguichips.com
------------------------------------------------------------------------
 Agradecimientos:
   lacyg, Hermes, carlosfer, djhuevo, iluso, hits, seymurx, Platinox,
   canibal, aleco, lOliveira, Sephiroth, Jademic, daro, patch_rippa ...
   a los foros de la zonaX - http://www.lazonax.net
   al apoyo decisivo de la webshop:
    http://www.murguichips.com (iluso y hits)
    http://www.spainconsoles.com
------------------------------------------------------------------------
ARNING:
  
   Read these instructions before use!
  
   Improper use of this program may cause damage to
   I am not responsible
                                                   Dampro.
------------------------------------------------------------------------                            

COMMENTS ABOUT THE NEW VERSION (1.2b)

In this version, mainly the detection of the versions of pstwo has been improved, now
The V12, 13, 14, 15 are detected .... the data are almost identical among them but in many
The old system, which used data from the first V12
All pstwo.

Many of the lens configuration data have been updated, all looking for more
compatibility. In addition, taking advantage of the existence of a good amount of
Different consoles have been created 3 sets of configuration data, selectable
For the user, in cases where it is desired to try other alternatives or when they do not give
Good result the default data.

In addition, the naming system for the eeprom backup files has been changed before
Was used the same name: "backup.nvm" ... it happened then, that if you worked with several
Consoles saved data of one could be mistakenly recorded in another, or also lose
The data by mistake, when overwriting them in another console.

Finally, an installer program has been developed, which makes it very simple to prepare the Lenschanger
To use it with the most common charging methods and thus work easily in a variety of
terms. These methods are: PS1 EXPLOIT, DEV1, SWAPMAGIC and direct load from CD.
The first three methods require a memory card to install the program into it,
Varying only the charging methods. In the case of loading from CD, from the same installer
Is given that option, so having the installer CD by hand and some console in
(With lens) will be enough to prepare the program in the MC and then
Use it with the method of loading that has been chosen.


--- FUNCTIONS:

These are all functions now available in version 1.2b:

/ \ Triangle - turns off the console (standby)
[] Square - information
O circle - select from 3 databases (allows to choose the one of better compatibility)
X equis - accept menu option
R1 - creates a backup file of the eeprom information (new system)
L1 - restores backup file to eeprom (new system)
R2 - creates a backup file of the eeprom information (old method, file
"Backup.nvm")
L2 - restore backup file to eeprom (old method, file "backup.nvm")

Note: The language setup screen has been removed, in this new version the language
Is taken from the system configuration of the console.

--- NEW CHOICE: SELECTING THE DATABASE

This option is activated by pressing "O" (circle) and a window will appear where you can
Choose one of 3 databases, in case of compatibility problems, this allows
Try another set of data, which can solve the problem or improve the redemption.
(Eye: can also make it worse) :)

It is advisable to normally use # 1, (which is most tested on almost all versions)
And try the other two only if you have problems with this one.

Also of course it is important to make sure that the hardware does not present problems
(Try lens, BA, cables, etc) as you might think it is a configuration problem
When in fact it is not. This can save a lot of headaches !!!

Another point to note are the old consoles V3, V4 and HD7 lenses. On these consoles only
SONY lenses were originally installed, therefore there is no real information extracted
Of a console of these versions working with HD7 lenses, but here is a "hack" that is
Does with non-original data of these consoles. However this works well in many V4,
But in some and especially in V3 does not work perfect and in many it is not possible to do them
to work. Unfortunately there is little that can be improved in this sense, only remains in cases
So test with the alternative data and check if it improves.

It is also necessary to take into account the mechanical incompatibilities due to the differences
Of the size between the KHS400B lenses (those used in the older versions) and the newer ones.
When installing a lens always check that there is no roze in all its route, as well
Such as verifying that it does not shock when opening the tray (for the KHS400B in more modern consoles)

Although there are ways to achieve such a lens, it is better in many cases to look for a lens
Appropriate for the console version being attempted to repair.

--- NEW SYSTEM FOR NAMING BACKUP FILES

In this version (1.2) the system has been changed to name the backup file of
The eeprom with a fixed name ("backup.nvm") this had several problems because only
There could be only one file per memory card, and you could erase the previous ones
By mistake, as well as programming incorrect data from another console.
To avoid this now each backup will have a console dependent name where
Has been created, this way you can have several at the same time in the same place without
Concerns, and avoid mistakes as each console will have its own.

The names are generated from the model of the console and part of its serial number, for
example:

SCPH-50004_12345.nvm
SCPH-39001_43534.nvm
SCPH-39001_67615.nvm


Having included the serial number of the console makes it unique for each.

However, the previous option to use the fixed name "backup.nvm" is
(Restore from an old backup, etc) this is done with R2 and L2.
When using this method it will be noticed that the old file name will be used.

--- NOTES
For any questions, ask in the forum:

Http://www.spainconsoles.com

Also check the readme of previous versions ....
There are still many details ...
There is no free program full of errors ...

.... END ....

Dampro.