# Open PS2 Loader Widescreen Hacks

![GitHub release (latest by date)](https://img.shields.io/github/downloads/PS2-Widescreen/OPL-Widescreen-Cheats/Latest/total?label=Downloads)
![available cheats](https://img.shields.io/github/directory-file-count/PS2-Widescreen/OPL-Widescreen-Cheats/CHT?color=gree&extension=cht&label=Available%20cheats&type=file)

Drop these cheat files in your /OPL/CHT folder to correct/add widescreen support for your PS2 games!

##### See available cheats table [here](https://github.com/PS2-Widescreen/OPL-Widescreen-Cheats/blob/main/cheat_list.MD)

So you have some sexy component cables on your big widescreen TV and you think you are ballin' hard?
Well sorry to break it to you but you aren't.
Most games do not have widescreen support so they just stretch the image.
Some games have widescreen options but they aren't always a proper widescreen.

These cheats will give you the best experience!

Just make sure you go to "Cheat Settings" and change "Enable PS2RD Cheat Engine" to "On" and change "PS2RD Cheat Engine Mode" to "Auto-select cheats".

This doesn't have every single game, and they haven't all been tested, but I am working on it. 

I am converting the .pnach files from this Widescreen patch archive:
https://forums.pcsx2.net/Thread-PCSX2-Widescreen-Game-Patches

Example:
<img src="https://i.imgur.com/gYElt.giff">

# Contribute to the project

this is the list of cheats that need testing and a mastercode:

You can find the actual cheat files [here](https://github.com/PS2-Widescreen/pnach-DB/blob/main/ONLY_MASTERCODE_MISSING.txt)
