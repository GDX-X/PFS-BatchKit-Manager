# Open PS2 Loader Widescreen Hacks

![GitHub release (latest by date)](https://img.shields.io/github/downloads/PS2-Widescreen/OPL-Widescreen-Cheats/Latest/total?label=Downloads)
![available cheats](https://img.shields.io/github/directory-file-count/PS2-Widescreen/OPL-Widescreen-Cheats/CHT?color=gree&extension=cht&label=Available%20cheats&type=file)

unzip the file and put the `CHT/` folder into the OPL File structure (`hdd0:/$OPL_PARTITION/` for HDD or device root for any other device)

##### See available cheats table [here](https://github.com/PS2-Widescreen/OPL-Widescreen-Cheats/blob/main/cheat_list.MD)

So you have some sexy component cables on your big widescreen TV and you think you are ballin' hard?
Well sorry to break it to you but you aren't.
Most games do not have widescreen support or a bad implementation of it (example: GTA - San Andreas)


These cheats will give you the best experience!

Just make sure you go to __Cheat Settings__ on OPL and change __Enable PS2RD Cheat Engine__ to __On__ and change __PS2RD Cheat Engine Mode__ to __Auto-select cheats__.

to avoid the hassle of manually picking wich games have widescreen cheats available, enable the cheats globally and paste the whole package, so if a cheat is available, it's automatically loaded.

I am converting most of them from the `.pnach` files from this Widescreen patch archive:
https://forums.pcsx2.net/Thread-PCSX2-Widescreen-Game-Patches

Example:
<img src="https://i.imgur.com/gYElt.giff">

# Contribute to the project

this is the [list of cheats that need testing and a mastercode](https://github.com/PS2-Widescreen/OPL-Widescreen-Cheats/blob/Latest/MISSING_MASTERCODE.TSV)
