jkt_001.png image size 256x256 this is your PSBBN game cover
jkt_002.png image size 256x256 this is your PSX DVR game cover (do not use this for PSBBN)
jkt_cp.png image size 290x46 this is an image file with copyright information, you can add any information here by adding your image with the correct name and dimensions
notice.png image size 416x196 file of brief information about the game or application, you can create your own
the image folder contains images that are displayed if you select Manual (instruction) in the context menu of the game
man.xml is a system file that contains information about the location of the image for the manual item (instruction), also the name of the game and application, and a link to the background image for instructions

in the image folder, in addition to images for instructions, there is a background image for instructions, you can replace it with your own, the file should have the name 01.png and size 640x480


title = Name of your game or app
title_id = usually specifies SLES-00000 game ID or partition name if the app is installed instead of the game
title_sub_id = 0 this parameter allows or prevents the display of additional ID 0 disabled, 1 enabled
release_date = 20190101 game or application release date
developer_id = SONY Developer is listed here
publisher_id = SONY Publisher specified here
note = sofware any additional information you wish, will be shown in the information section
content_web = http://ww.ps-gamers.ru web address related to your game or application,usually specified developer site
image_topviewflag = 0 is not yet known what it is, 0 is disabled, 1 is enabled
image_type = 0 is not yet known what it is, 0 is disabled, 1 is enabled
image_count = 1 is not yet known what it is, 0 disabled, 1 enabled
image_viewsec = 600 is not yet known what it is
copyright_viewflag = 1 This paragraph determines whether the game cover will display a file with the copyright information 0 off. 1on
copyright_imgcount = 1 something related to copyright information, exact information is not yet available
genre = Software genre of your game or application,
parental_lock = 1 is not yet known that this,0 is disabled, 1 is enabled
effective_date = 0 is not yet known that this,0 is disabled, 1 is enabled
expire_date = 0 is not yet known that this,0 is disabled, 1 is enabled
violence_flag = 0 is not yet known to be disabled, 1 enabled
content_type = 255 type of content,if put 261 game or application will not be displayed in HDD OSD,only in PSBBN
content_subtype = 0 indication of additional type of content,it is not yet known how to use 1on 0 off
after you have copied all the necessary files into PP section. you need to make it bootable so you can run your game from the PSBBN