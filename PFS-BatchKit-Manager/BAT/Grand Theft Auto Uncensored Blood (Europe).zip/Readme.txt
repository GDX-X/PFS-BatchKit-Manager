How do I know my version of my Grand Theft Auto.

Mount or Open your .ISO with Winrar and Open system.cnf and check VER =

.CHT = Open PS2 Loader
.PNACH = PCSX2

Why the German version doesn't have the blood. 
Because I think rockstar has removed the blood texture for the German version
(If you find a solution contact me on discord)


Discord: GDX#5466